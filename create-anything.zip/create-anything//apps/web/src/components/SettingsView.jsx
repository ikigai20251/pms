import React, { useState } from "react";
import {
  Settings,
  User,
  Building,
  Palette,
  Bell,
  Shield,
  CreditCard,
  Globe,
  Save,
  Upload,
  Plus,
  Trash2,
  Edit3,
} from "lucide-react";

export default function SettingsView({ workspaceId, userId }) {
  const [activeTab, setActiveTab] = useState("workspace");
  const [workspaceSettings, setWorkspaceSettings] = useState({
    name: "My Agency",
    description: "Full-service digital agency",
    logo_url: "",
    primary_color: "#3B82F6",
    timezone: "UTC-5",
    currency: "USD",
    business_hours: {
      start: "09:00",
      end: "17:00",
      days: ["mon", "tue", "wed", "thu", "fri"]
    }
  });

  const [userSettings, setUserSettings] = useState({
    first_name: "John",
    last_name: "Doe",
    email: "john.doe@example.com",
    avatar_url: "",
    hourly_rate: 100,
    notifications: {
      email: true,
      desktop: true,
      task_assignments: true,
      project_updates: true,
      time_reminders: true
    }
  });

  const [taskStatuses, setTaskStatuses] = useState([
    { id: 1, name: "To Do", color: "#6B7280", is_default: true, is_done: false },
    { id: 2, name: "In Progress", color: "#F59E0B", is_default: false, is_done: false },
    { id: 3, name: "In Review", color: "#8B5CF6", is_default: false, is_done: false },
    { id: 4, name: "Done", color: "#10B981", is_default: false, is_done: true },
  ]);

  const [taskLabels, setTaskLabels] = useState([
    { id: 1, name: "Bug", color: "#EF4444" },
    { id: 2, name: "Feature", color: "#3B82F6" },
    { id: 3, name: "Enhancement", color: "#10B981" },
    { id: 4, name: "Urgent", color: "#F59E0B" },
  ]);

  const tabs = [
    { id: "workspace", name: "Workspace", icon: Building },
    { id: "profile", name: "Profile", icon: User },
    { id: "task-settings", name: "Task Settings", icon: Settings },
    { id: "notifications", name: "Notifications", icon: Bell },
    { id: "billing", name: "Billing", icon: CreditCard },
    { id: "security", name: "Security", icon: Shield },
  ];

  const timezones = [
    { value: "UTC-12", label: "(UTC-12:00) International Date Line West" },
    { value: "UTC-8", label: "(UTC-08:00) Pacific Time (US & Canada)" },
    { value: "UTC-5", label: "(UTC-05:00) Eastern Time (US & Canada)" },
    { value: "UTC+0", label: "(UTC+00:00) Greenwich Mean Time" },
    { value: "UTC+1", label: "(UTC+01:00) Central European Time" },
  ];

  const currencies = [
    { value: "USD", label: "US Dollar ($)" },
    { value: "EUR", label: "Euro (€)" },
    { value: "GBP", label: "British Pound (£)" },
    { value: "CAD", label: "Canadian Dollar (C$)" },
  ];

  const renderWorkspaceSettings = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">General Settings</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Workspace Name
            </label>
            <input
              type="text"
              value={workspaceSettings.name}
              onChange={(e) =>
                setWorkspaceSettings({ ...workspaceSettings, name: e.target.value })
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Primary Color
            </label>
            <div className="flex items-center space-x-2">
              <input
                type="color"
                value={workspaceSettings.primary_color}
                onChange={(e) =>
                  setWorkspaceSettings({ ...workspaceSettings, primary_color: e.target.value })
                }
                className="w-12 h-10 border border-gray-300 rounded-md"
              />
              <input
                type="text"
                value={workspaceSettings.primary_color}
                onChange={(e) =>
                  setWorkspaceSettings({ ...workspaceSettings, primary_color: e.target.value })
                }
                className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Timezone
            </label>
            <select
              value={workspaceSettings.timezone}
              onChange={(e) =>
                setWorkspaceSettings({ ...workspaceSettings, timezone: e.target.value })
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {timezones.map((tz) => (
                <option key={tz.value} value={tz.value}>
                  {tz.label}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Currency
            </label>
            <select
              value={workspaceSettings.currency}
              onChange={(e) =>
                setWorkspaceSettings({ ...workspaceSettings, currency: e.target.value })
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {currencies.map((currency) => (
                <option key={currency.value} value={currency.value}>
                  {currency.label}
                </option>
              ))}
            </select>
          </div>
        </div>
        <div className="mt-4">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Description
          </label>
          <textarea
            value={workspaceSettings.description}
            onChange={(e) =>
              setWorkspaceSettings({ ...workspaceSettings, description: e.target.value })
            }
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            rows="3"
          />
        </div>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Logo & Branding</h3>
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
          <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
          <p className="text-sm text-gray-600 mb-2">Upload your workspace logo</p>
          <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">
            Choose File
          </button>
        </div>
      </div>
    </div>
  );

  const renderProfileSettings = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Personal Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              First Name
            </label>
            <input
              type="text"
              value={userSettings.first_name}
              onChange={(e) =>
                setUserSettings({ ...userSettings, first_name: e.target.value })
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Last Name
            </label>
            <input
              type="text"
              value={userSettings.last_name}
              onChange={(e) =>
                setUserSettings({ ...userSettings, last_name: e.target.value })
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Email
            </label>
            <input
              type="email"
              value={userSettings.email}
              onChange={(e) =>
                setUserSettings({ ...userSettings, email: e.target.value })
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Hourly Rate ($)
            </label>
            <input
              type="number"
              value={userSettings.hourly_rate}
              onChange={(e) =>
                setUserSettings({ ...userSettings, hourly_rate: parseInt(e.target.value) })
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Profile Picture</h3>
        <div className="flex items-center space-x-6">
          <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center">
            {userSettings.avatar_url ? (
              <img
                src={userSettings.avatar_url}
                alt="Profile"
                className="w-16 h-16 rounded-full object-cover"
              />
            ) : (
              <User className="h-8 w-8 text-gray-400" />
            )}
          </div>
          <div>
            <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 mr-2">
              Upload Photo
            </button>
            <button className="bg-gray-200 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-300">
              Remove
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderTaskSettings = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Task Statuses</h3>
        <div className="space-y-2 mb-4">
          {taskStatuses.map((status) => (
            <div
              key={status.id}
              className="flex items-center justify-between p-3 border border-gray-200 rounded-md"
            >
              <div className="flex items-center space-x-3">
                <div
                  className="w-4 h-4 rounded-full"
                  style={{ backgroundColor: status.color }}
                ></div>
                <span className="font-medium">{status.name}</span>
                {status.is_default && (
                  <span className="px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded-full">
                    Default
                  </span>
                )}
                {status.is_done && (
                  <span className="px-2 py-1 text-xs bg-green-100 text-green-800 rounded-full">
                    Done Status
                  </span>
                )}
              </div>
              <div className="flex items-center space-x-2">
                <button className="text-gray-400 hover:text-gray-600">
                  <Edit3 className="h-4 w-4" />
                </button>
                <button className="text-red-400 hover:text-red-600">
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
        <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 flex items-center">
          <Plus className="h-4 w-4 mr-2" />
          Add Status
        </button>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Task Labels</h3>
        <div className="space-y-2 mb-4">
          {taskLabels.map((label) => (
            <div
              key={label.id}
              className="flex items-center justify-between p-3 border border-gray-200 rounded-md"
            >
              <div className="flex items-center space-x-3">
                <div
                  className="w-4 h-4 rounded-full"
                  style={{ backgroundColor: label.color }}
                ></div>
                <span className="font-medium">{label.name}</span>
              </div>
              <div className="flex items-center space-x-2">
                <button className="text-gray-400 hover:text-gray-600">
                  <Edit3 className="h-4 w-4" />
                </button>
                <button className="text-red-400 hover:text-red-600">
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
        <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 flex items-center">
          <Plus className="h-4 w-4 mr-2" />
          Add Label
        </button>
      </div>
    </div>
  );

  const renderNotificationSettings = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Notification Preferences</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium text-gray-900">Email Notifications</h4>
              <p className="text-sm text-gray-500">Receive notifications via email</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={userSettings.notifications.email}
                onChange={(e) =>
                  setUserSettings({
                    ...userSettings,
                    notifications: {
                      ...userSettings.notifications,
                      email: e.target.checked,
                    },
                  })
                }
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium text-gray-900">Task Assignments</h4>
              <p className="text-sm text-gray-500">When you're assigned to a task</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={userSettings.notifications.task_assignments}
                onChange={(e) =>
                  setUserSettings({
                    ...userSettings,
                    notifications: {
                      ...userSettings.notifications,
                      task_assignments: e.target.checked,
                    },
                  })
                }
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium text-gray-900">Project Updates</h4>
              <p className="text-sm text-gray-500">When projects you're involved in are updated</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={userSettings.notifications.project_updates}
                onChange={(e) =>
                  setUserSettings({
                    ...userSettings,
                    notifications: {
                      ...userSettings.notifications,
                      project_updates: e.target.checked,
                    },
                  })
                }
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium text-gray-900">Time Reminders</h4>
              <p className="text-sm text-gray-500">Reminders to track your time</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={userSettings.notifications.time_reminders}
                onChange={(e) =>
                  setUserSettings({
                    ...userSettings,
                    notifications: {
                      ...userSettings.notifications,
                      time_reminders: e.target.checked,
                    },
                  })
                }
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
        </div>
      </div>
    </div>
  );

  const renderTabContent = () => {
    switch (activeTab) {
      case "workspace":
        return renderWorkspaceSettings();
      case "profile":
        return renderProfileSettings();
      case "task-settings":
        return renderTaskSettings();
      case "notifications":
        return renderNotificationSettings();
      case "billing":
        return (
          <div className="text-center py-12">
            <CreditCard className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Billing Settings</h3>
            <p className="text-gray-500">
              Manage your subscription, payment methods, and billing history
            </p>
          </div>
        );
      case "security":
        return (
          <div className="text-center py-12">
            <Shield className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Security Settings</h3>
            <p className="text-gray-500">
              Manage your password, two-factor authentication, and security preferences
            </p>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="h-full overflow-y-auto">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
            <p className="text-sm text-gray-500 mt-1">
              Manage your workspace preferences and account settings
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 flex items-center">
              <Save className="h-4 w-4 mr-2" />
              Save Changes
            </button>
          </div>
        </div>
      </div>

      <div className="flex h-full">
        {/* Sidebar */}
        <div className="w-64 bg-white border-r border-gray-200">
          <nav className="p-4 space-y-2">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                    activeTab === tab.id
                      ? "bg-blue-50 text-blue-700 border-r-2 border-blue-500"
                      : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                  }`}
                >
                  <Icon className="mr-3 h-5 w-5" />
                  {tab.name}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Content */}
        <div className="flex-1 p-6">
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
}