import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  BarChart3,
  Download,
  Calendar,
  Filter,
  TrendingUp,
  DollarSign,
  Clock,
  Users,
  Target,
  FileText,
} from "lucide-react";

export default function ReportsView({ workspaceId, userId }) {
  const [reportType, setReportType] = useState("time_tracking");
  const [dateRange, setDateRange] = useState("this_month");
  const [selectedProject, setSelectedProject] = useState("all");

  // Fetch reports data
  const { data: reportData, isLoading } = useQuery({
    queryKey: ["reports", workspaceId, reportType, dateRange, selectedProject],
    queryFn: async () => {
      const params = new URLSearchParams({
        workspace_id: workspaceId,
        type: reportType,
      });

      if (dateRange !== "all_time") {
        const now = new Date();
        let startDate;
        
        switch (dateRange) {
          case "today":
            startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
            break;
          case "this_week":
            startDate = new Date(now.setDate(now.getDate() - now.getDay()));
            break;
          case "this_month":
            startDate = new Date(now.getFullYear(), now.getMonth(), 1);
            break;
          case "this_year":
            startDate = new Date(now.getFullYear(), 0, 1);
            break;
        }
        
        if (startDate) {
          params.append("start_date", startDate.toISOString());
        }
      }

      if (selectedProject !== "all") {
        params.append("project_id", selectedProject);
      }

      const response = await fetch(`/api/reports?${params}`);
      if (!response.ok) {
        throw new Error("Failed to fetch reports");
      }
      return response.json();
    },
  });

  // Fetch projects for filter
  const { data: projects = [] } = useQuery({
    queryKey: ["projects", workspaceId],
    queryFn: async () => {
      const response = await fetch(`/api/projects?workspace_id=${workspaceId}`);
      if (!response.ok) return [];
      return response.json();
    },
  });

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(amount || 0);
  };

  const formatTime = (hours) => {
    const h = Math.floor(hours);
    const m = Math.round((hours - h) * 60);
    return `${h}h ${m}m`;
  };

  const reportTypes = [
    { id: "time_tracking", name: "Time Tracking", icon: Clock },
    { id: "project_profitability", name: "Project Profitability", icon: DollarSign },
    { id: "team_productivity", name: "Team Productivity", icon: Users },
    { id: "client_revenue", name: "Client Revenue", icon: TrendingUp },
    { id: "task_completion", name: "Task Completion", icon: Target },
    { id: "financial_summary", name: "Financial Summary", icon: BarChart3 },
  ];

  if (isLoading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-gray-600">Generating reports...</p>
        </div>
      </div>
    );
  }

  const renderReportContent = () => {
    if (!reportData?.data) {
      return (
        <div className="text-center py-12">
          <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No data available</h3>
          <p className="text-gray-500">
            Try adjusting your filters or date range to see report data
          </p>
        </div>
      );
    }

    switch (reportType) {
      case "time_tracking":
        return (
          <div className="space-y-6">
            {reportData.summary && (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-blue-600 text-sm font-medium">Total Entries</p>
                  <p className="text-2xl font-bold text-blue-900">{reportData.summary.total_entries}</p>
                </div>
                <div className="bg-green-50 p-4 rounded-lg">
                  <p className="text-green-600 text-sm font-medium">Total Hours</p>
                  <p className="text-2xl font-bold text-green-900">{formatTime(reportData.summary.total_hours)}</p>
                </div>
                <div className="bg-yellow-50 p-4 rounded-lg">
                  <p className="text-yellow-600 text-sm font-medium">Billable Hours</p>
                  <p className="text-2xl font-bold text-yellow-900">{formatTime(reportData.summary.total_billable_hours)}</p>
                </div>
                <div className="bg-purple-50 p-4 rounded-lg">
                  <p className="text-purple-600 text-sm font-medium">Total Revenue</p>
                  <p className="text-2xl font-bold text-purple-900">{formatCurrency(reportData.summary.total_revenue)}</p>
                </div>
              </div>
            )}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="px-6 py-4 border-b border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900">Time Entries</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Task</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Project</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">User</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Hours</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Revenue</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {reportData.data.slice(0, 10).map((entry, index) => (
                      <tr key={index}>
                        <td className="px-6 py-4 text-sm text-gray-900">{entry.task_title}</td>
                        <td className="px-6 py-4 text-sm text-gray-900">{entry.project_name}</td>
                        <td className="px-6 py-4 text-sm text-gray-900">{entry.user_name}</td>
                        <td className="px-6 py-4 text-sm text-gray-900">{formatTime(entry.hours)}</td>
                        <td className="px-6 py-4 text-sm text-gray-900">{formatCurrency(entry.revenue)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );

      case "project_profitability":
        return (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="px-6 py-4 border-b border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900">Project Profitability</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Project</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Client</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Budget</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Revenue</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Hours</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tasks</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Margin</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {reportData.data.map((project) => (
                    <tr key={project.id}>
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">{project.name}</td>
                      <td className="px-6 py-4 text-sm text-gray-900">{project.client_name || "—"}</td>
                      <td className="px-6 py-4 text-sm text-gray-900">{formatCurrency(project.budget)}</td>
                      <td className="px-6 py-4 text-sm text-gray-900">{formatCurrency(project.total_revenue)}</td>
                      <td className="px-6 py-4 text-sm text-gray-900">{formatTime(project.total_billable_hours)}</td>
                      <td className="px-6 py-4 text-sm text-gray-900">{project.completed_tasks}/{project.total_tasks}</td>
                      <td className="px-6 py-4 text-sm">
                        <span className={`${
                          project.profit_margin_percentage > 0 ? 'text-green-600' : 'text-red-600'
                        } font-medium`}>
                          {project.profit_margin_percentage}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      case "team_productivity":
        return (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="px-6 py-4 border-b border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900">Team Productivity</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Team Member</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tasks</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Completion Rate</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Hours</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Revenue</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Rate</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {reportData.data.map((member) => (
                    <tr key={member.id}>
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">{member.name}</td>
                      <td className="px-6 py-4 text-sm text-gray-900">
                        {member.completed_tasks}/{member.assigned_tasks}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-900">{member.completion_rate}%</td>
                      <td className="px-6 py-4 text-sm text-gray-900">{formatTime(member.total_hours)}</td>
                      <td className="px-6 py-4 text-sm text-gray-900">{formatCurrency(member.revenue_generated)}</td>
                      <td className="px-6 py-4 text-sm text-gray-900">{formatCurrency(member.hourly_rate)}/h</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      default:
        return (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">📊</div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {reportTypes.find(r => r.id === reportType)?.name} Report
            </h3>
            <p className="text-gray-500">
              Detailed {reportType.replace('_', ' ')} analytics will be displayed here
            </p>
          </div>
        );
    }
  };

  return (
    <div className="h-full overflow-y-auto">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Reports</h1>
            <p className="text-sm text-gray-500 mt-1">
              Analyze your business performance and team productivity
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <button className="bg-gray-100 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-200 flex items-center">
              <Download className="h-4 w-4 mr-2" />
              Export Report
            </button>
          </div>
        </div>
      </div>

      {/* Report Types */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex flex-wrap gap-2">
          {reportTypes.map((type) => {
            const Icon = type.icon;
            return (
              <button
                key={type.id}
                onClick={() => setReportType(type.id)}
                className={`flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  reportType === type.id
                    ? "bg-blue-100 text-blue-700 border border-blue-200"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                <Icon className="h-4 w-4 mr-2" />
                {type.name}
              </button>
            );
          })}
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between space-y-4 md:space-y-0">
          <div className="flex items-center space-x-4">
            {/* Date Range */}
            <div className="flex items-center space-x-2">
              <Calendar className="h-4 w-4 text-gray-400" />
              <select
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="today">Today</option>
                <option value="this_week">This Week</option>
                <option value="this_month">This Month</option>
                <option value="this_year">This Year</option>
                <option value="all_time">All Time</option>
              </select>
            </div>

            {/* Project Filter */}
            <div className="flex items-center space-x-2">
              <Filter className="h-4 w-4 text-gray-400" />
              <select
                value={selectedProject}
                onChange={(e) => setSelectedProject(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="all">All Projects</option>
                {projects.map((project) => (
                  <option key={project.id} value={project.id}>
                    {project.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Report Content */}
      <div className="p-6">
        {renderReportContent()}
      </div>
    </div>
  );
}