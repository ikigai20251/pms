"use client";

import React, { useState } from "react";
import {
  useQuery,
  useMutation,
  useQueryClient,
  QueryClient,
  QueryClientProvider,
} from "@tanstack/react-query";
import { Toaster, toast } from "sonner";
import {
  LayoutDashboard,
  FolderOpen,
  CheckSquare,
  Clock,
  Users,
  Settings,
  Plus,
  Pause,
  DollarSign,
  Database,
  BarChart3,
} from "lucide-react";

// Components
import DashboardView from "../components/DashboardView";
import ProjectsView from "../components/ProjectsView";
import TasksView from "../components/TasksView";
import TimeTrackingView from "../components/TimeTrackingView";
import TeamView from "../components/TeamView";
import ReportsView from "../components/ReportsView";
import SettingsView from "../components/SettingsView";

// Create a client
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
    },
  },
});

// Mock workspace ID for demo purposes - in a real app this would come from auth/context
const DEMO_WORKSPACE_ID = 1;
const DEMO_USER_ID = 1;

function ProjectManagementApp() {
  const [activeView, setActiveView] = useState("dashboard");
  const queryClient = useQueryClient();

  // Fetch dashboard data for the sidebar stats
  const { data: dashboardData, isLoading: dashboardLoading } = useQuery({
    queryKey: ["dashboard", DEMO_WORKSPACE_ID],
    queryFn: async () => {
      const response = await fetch(
        `/api/dashboard?workspace_id=${DEMO_WORKSPACE_ID}&user_id=${DEMO_USER_ID}`,
      );
      if (!response.ok) {
        throw new Error("Failed to fetch dashboard data");
      }
      return response.json();
    },
  });

  // Seed database mutation
  const seedDataMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/seed", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      if (!response.ok) {
        throw new Error("Failed to seed database");
      }
      return response.json();
    },
    onSuccess: (data) => {
      toast.success(
        `Database seeded successfully! Added ${data.counts.projects} projects, ${data.counts.tasks} tasks, and more.`,
      );
      queryClient.invalidateQueries({ queryKey: ["dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["projects"] });
      queryClient.invalidateQueries({ queryKey: ["tasks"] });
      queryClient.invalidateQueries({ queryKey: ["team"] });
    },
    onError: (error) => {
      toast.error("Failed to seed database: " + error.message);
    },
  });

  const stats = dashboardData?.stats || {};
  const currentTimer = dashboardData?.currentTimer;
  const hasData = dashboardData?.activeProjects?.length > 0;

  // Navigation items
  const navigation = [
    { 
      id: "dashboard", 
      name: "Dashboard", 
      icon: LayoutDashboard,
      badge: stats.overdue_tasks > 0 ? stats.overdue_tasks : null,
      badgeColor: "bg-red-500"
    },
    { 
      id: "projects", 
      name: "Projects", 
      icon: FolderOpen,
      badge: stats.active_projects || null,
      badgeColor: "bg-blue-500"
    },
    { 
      id: "tasks", 
      name: "Tasks", 
      icon: CheckSquare,
      badge: stats.open_tasks || null,
      badgeColor: "bg-yellow-500"
    },
    { 
      id: "time", 
      name: "Time Tracking", 
      icon: Clock,
      badge: currentTimer ? "●" : null,
      badgeColor: "bg-green-500"
    },
    { 
      id: "team", 
      name: "Team", 
      icon: Users,
    },
    { 
      id: "reports", 
      name: "Reports", 
      icon: BarChart3,
    },
    { 
      id: "settings", 
      name: "Settings", 
      icon: Settings,
    },
  ];

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(amount || 0);
  };

  // Render active view
  const renderActiveView = () => {
    switch (activeView) {
      case "dashboard":
        return <DashboardView workspaceId={DEMO_WORKSPACE_ID} userId={DEMO_USER_ID} />;
      case "projects":
        return <ProjectsView workspaceId={DEMO_WORKSPACE_ID} userId={DEMO_USER_ID} />;
      case "tasks":
        return <TasksView workspaceId={DEMO_WORKSPACE_ID} userId={DEMO_USER_ID} />;
      case "time":
        return <TimeTrackingView workspaceId={DEMO_WORKSPACE_ID} userId={DEMO_USER_ID} />;
      case "team":
        return <TeamView workspaceId={DEMO_WORKSPACE_ID} userId={DEMO_USER_ID} />;
      case "reports":
        return <ReportsView workspaceId={DEMO_WORKSPACE_ID} userId={DEMO_USER_ID} />;
      case "settings":
        return <SettingsView workspaceId={DEMO_WORKSPACE_ID} userId={DEMO_USER_ID} />;
      default:
        return <DashboardView workspaceId={DEMO_WORKSPACE_ID} userId={DEMO_USER_ID} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-sm border-r border-gray-200 flex flex-col">
        {/* Logo/Brand */}
        <div className="p-6 border-b border-gray-200">
          <h1 className="text-xl font-bold text-gray-900">ProjectPro</h1>
          <p className="text-sm text-gray-500">Complete Project Management</p>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-4 py-4 space-y-1">
          {navigation.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setActiveView(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                  activeView === item.id
                    ? "bg-blue-50 text-blue-700 border-r-2 border-blue-500"
                    : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                }`}
              >
                <div className="flex items-center">
                  <Icon className="mr-3 h-5 w-5" />
                  {item.name}
                </div>
                {item.badge && (
                  <span className={`${item.badgeColor} text-white text-xs px-2 py-1 rounded-full`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Quick Stats */}
        <div className="p-4 border-t border-gray-200 bg-gray-50">
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="text-center">
              <div className="font-semibold text-gray-900">{stats.active_projects || 0}</div>
              <div className="text-gray-500">Projects</div>
            </div>
            <div className="text-center">
              <div className="font-semibold text-gray-900">{stats.open_tasks || 0}</div>
              <div className="text-gray-500">Tasks</div>
            </div>
            <div className="text-center col-span-2">
              <div className="font-semibold text-green-600">{formatCurrency(stats.revenue_this_month)}</div>
              <div className="text-gray-500">This Month</div>
            </div>
          </div>
        </div>

        {/* Demo Data Seed Button */}
        {!hasData && (
          <div className="p-4 border-t border-gray-200 bg-blue-50">
            <p className="text-xs text-gray-600 mb-2">
              Want to see the system in action?
            </p>
            <button
              onClick={() => seedDataMutation.mutate()}
              disabled={seedDataMutation.isLoading}
              className="w-full bg-blue-600 text-white px-3 py-2 text-sm rounded-md hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center"
            >
              {seedDataMutation.isLoading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
              ) : (
                <Database className="h-4 w-4 mr-2" />
              )}
              Load Demo Data
            </button>
          </div>
        )}

        {/* Current Timer */}
        {currentTimer && (
          <div className="p-4 border-t border-gray-200 bg-green-50">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse mr-2"></div>
                <span className="text-sm font-medium text-gray-900">
                  Timer Running
                </span>
              </div>
              <button className="text-green-600 hover:text-green-800">
                <Pause className="h-4 w-4" />
              </button>
            </div>
            <p className="text-xs text-gray-600 mt-1 truncate">
              {currentTimer.task_title}
            </p>
            <p className="text-xs text-gray-500 truncate">{currentTimer.project_name}</p>
          </div>
        )}
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-hidden">
        {renderActiveView()}
      </div>
    </div>
  );
}

export default function HomePage() {
  return (
    <QueryClientProvider client={queryClient}>
      <div>
        <ProjectManagementApp />
        <Toaster position="top-right" />
      </div>
    </QueryClientProvider>
  );
}