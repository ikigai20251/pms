import sql from "@/app/api/utils/sql";

// Get dashboard data
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const workspaceId = searchParams.get('workspace_id');
    const userId = searchParams.get('user_id');

    if (!workspaceId) {
      return Response.json({ error: 'Workspace ID is required' }, { status: 400 });
    }

    // Get overview stats
    const [stats] = await sql`
      SELECT 
        COUNT(DISTINCT CASE WHEN p.status = 'active' THEN p.id END) as active_projects,
        COUNT(DISTINCT CASE WHEN t.completion_percentage < 100 THEN t.id END) as open_tasks,
        COUNT(DISTINCT CASE WHEN t.due_date < CURRENT_DATE AND t.completion_percentage < 100 THEN t.id END) as overdue_tasks,
        COALESCE(SUM(te.hours), 0) as total_hours_today,
        COALESCE(SUM(CASE WHEN te.is_billable THEN te.billable_hours * te.hourly_rate ELSE 0 END), 0) as revenue_this_month
      FROM projects p
      LEFT JOIN tasks t ON p.id = t.project_id
      LEFT JOIN time_entries te ON t.id = te.task_id AND DATE(te.created_at) = CURRENT_DATE
      WHERE p.workspace_id = ${workspaceId}
    `;

    // Get recent activity
    const recentActivity = await sql`
      SELECT 
        'task_created' as type,
        t.title as title,
        p.name as project_name,
        t.created_at as timestamp,
        u.first_name || ' ' || u.last_name as user_name
      FROM tasks t
      JOIN projects p ON t.project_id = p.id
      LEFT JOIN users u ON t.reporter_id = u.id
      WHERE p.workspace_id = ${workspaceId}
      
      UNION ALL
      
      SELECT 
        'time_logged' as type,
        'Logged ' || te.hours || ' hours on ' || t.title as title,
        p.name as project_name,
        te.created_at as timestamp,
        u.first_name || ' ' || u.last_name as user_name
      FROM time_entries te
      JOIN tasks t ON te.task_id = t.id
      JOIN projects p ON t.project_id = p.id
      LEFT JOIN users u ON te.user_id = u.id
      WHERE p.workspace_id = ${workspaceId}
      
      ORDER BY timestamp DESC
      LIMIT 10
    `;

    // Get upcoming deadlines
    const upcomingDeadlines = await sql`
      SELECT 
        t.id,
        t.title,
        t.due_date,
        t.priority,
        p.name as project_name,
        p.color as project_color,
        assignee.first_name || ' ' || assignee.last_name as assignee_name
      FROM tasks t
      JOIN projects p ON t.project_id = p.id
      LEFT JOIN users assignee ON t.assignee_id = assignee.id
      WHERE p.workspace_id = ${workspaceId}
        AND t.due_date IS NOT NULL
        AND t.due_date >= CURRENT_DATE
        AND t.completion_percentage < 100
      ORDER BY t.due_date ASC
      LIMIT 5
    `;

    // Get active projects with progress
    const activeProjects = await sql`
      SELECT 
        p.*,
        c.name as client_name,
        COUNT(DISTINCT t.id) as total_tasks,
        COUNT(DISTINCT CASE WHEN ts.is_done = true THEN t.id END) as completed_tasks,
        COALESCE(SUM(te.billable_hours), 0) as total_hours,
        COALESCE(SUM(te.billable_hours * te.hourly_rate), 0) as total_revenue
      FROM projects p
      LEFT JOIN clients c ON p.client_id = c.id
      LEFT JOIN tasks t ON p.id = t.project_id
      LEFT JOIN task_statuses ts ON t.status_id = ts.id
      LEFT JOIN time_entries te ON t.id = te.task_id AND te.is_billable = true
      WHERE p.workspace_id = ${workspaceId} AND p.status = 'active'
      GROUP BY p.id, c.name
      ORDER BY p.updated_at DESC
      LIMIT 6
    `;

    // Get time tracking data for current user if specified
    let currentTimer = null;
    if (userId) {
      [currentTimer] = await sql`
        SELECT te.*, 
               t.title as task_title,
               p.name as project_name
        FROM time_entries te
        JOIN tasks t ON te.task_id = t.id
        JOIN projects p ON t.project_id = p.id
        WHERE te.user_id = ${userId} AND te.is_running = true
        LIMIT 1
      `;
    }

    return Response.json({
      stats,
      recentActivity,
      upcomingDeadlines,
      activeProjects,
      currentTimer
    });
  } catch (error) {
    console.error('Error fetching dashboard data:', error);
    return Response.json({ error: 'Failed to fetch dashboard data' }, { status: 500 });
  }
}