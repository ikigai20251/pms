import sql from "@/app/api/utils/sql";

// Seed the database with demo data
export async function POST(request) {
  try {
    console.log('Starting database seed...');

    // Clear existing data (for demo purposes)
    await sql`DELETE FROM time_entries`;
    await sql`DELETE FROM comments`;
    await sql`DELETE FROM task_checklist_items`;
    await sql`DELETE FROM task_dependencies`;
    await sql`DELETE FROM task_label_assignments`;
    await sql`DELETE FROM tasks`;
    await sql`DELETE FROM project_members`;
    await sql`DELETE FROM projects`;
    await sql`DELETE FROM clients`;
    await sql`DELETE FROM workspace_members`;
    await sql`DELETE FROM workspaces`;
    await sql`DELETE FROM users`;
    await sql`DELETE FROM task_statuses WHERE workspace_id IS NOT NULL`;

    console.log('Cleared existing data');

    // Create demo users
    const users = await sql`
      INSERT INTO users (id, email, first_name, last_name, role, hourly_rate, avatar_url) VALUES
      (1, 'john@example.com', 'John', 'Smith', 'admin', 85.00, 'https://api.dicebear.com/7.x/avataaars/svg?seed=john'),
      (2, 'sarah@example.com', 'Sarah', 'Johnson', 'manager', 75.00, 'https://api.dicebear.com/7.x/avataaars/svg?seed=sarah'),
      (3, 'mike@example.com', 'Mike', 'Chen', 'member', 65.00, 'https://api.dicebear.com/7.x/avataaars/svg?seed=mike'),
      (4, 'emma@example.com', 'Emma', 'Davis', 'member', 70.00, 'https://api.dicebear.com/7.x/avataaars/svg?seed=emma'),
      (5, 'client1@acmecorp.com', 'Alice', 'Wilson', 'client', 0, 'https://api.dicebear.com/7.x/avataaars/svg?seed=alice'),
      (6, 'client2@techstartup.com', 'Bob', 'Taylor', 'client', 0, 'https://api.dicebear.com/7.x/avataaars/svg?seed=bob')
      ON CONFLICT (id) DO UPDATE SET
        email = EXCLUDED.email,
        first_name = EXCLUDED.first_name,
        last_name = EXCLUDED.last_name
      RETURNING *
    `;

    console.log('Created users:', users.length);

    // Create demo workspace
    const [workspace] = await sql`
      INSERT INTO workspaces (id, name, slug, description, primary_color, owner_id) VALUES
      (1, 'Digital Agency Pro', 'digital-agency-pro', 'Full-service digital agency specializing in web development and marketing', '#3B82F6', 1)
      ON CONFLICT (id) DO UPDATE SET
        name = EXCLUDED.name,
        slug = EXCLUDED.slug
      RETURNING *
    `;

    console.log('Created workspace:', workspace);

    // Add workspace members
    await sql`
      INSERT INTO workspace_members (workspace_id, user_id, role) VALUES
      (1, 1, 'admin'),
      (1, 2, 'manager'),
      (1, 3, 'member'),
      (1, 4, 'member'),
      (1, 5, 'client'),
      (1, 6, 'client')
      ON CONFLICT (workspace_id, user_id) DO NOTHING
    `;

    // Create demo clients
    const clients = await sql`
      INSERT INTO clients (id, workspace_id, name, email, phone, company, address, hourly_rate_override) VALUES
      (1, 1, 'Alice Wilson', 'alice@acmecorp.com', '+1-555-0123', 'Acme Corporation', '123 Business Ave, City, State 12345', 95.00),
      (2, 1, 'Bob Taylor', 'bob@techstartup.com', '+1-555-0124', 'Tech Startup Inc', '456 Innovation Dr, City, State 12346', 105.00),
      (3, 1, 'Carol Brown', 'carol@retailcompany.com', '+1-555-0125', 'Retail Company LLC', '789 Commerce St, City, State 12347', 85.00)
      ON CONFLICT (id) DO UPDATE SET
        name = EXCLUDED.name,
        email = EXCLUDED.email
      RETURNING *
    `;

    console.log('Created clients:', clients.length);

    // Create custom task statuses for workspace
    await sql`
      INSERT INTO task_statuses (workspace_id, name, color, is_default, is_done, sort_order) VALUES
      (1, 'Backlog', '#6B7280', false, false, 0),
      (1, 'To Do', '#3B82F6', true, false, 1),
      (1, 'In Progress', '#F59E0B', false, false, 2),
      (1, 'In Review', '#8B5CF6', false, false, 3),
      (1, 'Done', '#10B981', false, true, 4)
      ON CONFLICT DO NOTHING
    `;

    // Create demo projects
    const projects = await sql`
      INSERT INTO projects (
        id, workspace_id, client_id, name, description, status, priority, color, 
        budget, budget_type, hourly_rate, start_date, due_date, completion_percentage, created_by
      ) VALUES
      (1, 1, 1, 'E-commerce Website Redesign', 'Complete redesign of Acme Corporation e-commerce platform with modern UI/UX', 'active', 'high', '#10B981', 45000.00, 'fixed', 95.00, '2024-10-01', '2024-12-15', 75, 1),
      (2, 1, 2, 'Mobile App Development', 'Native iOS and Android app for Tech Startup customer portal', 'active', 'urgent', '#F59E0B', 80000.00, 'fixed', 105.00, '2024-09-15', '2024-11-30', 60, 1),
      (3, 1, 3, 'SEO & Content Strategy', 'Comprehensive SEO audit and content marketing strategy implementation', 'active', 'medium', '#8B5CF6', 15000.00, 'hourly', 85.00, '2024-10-15', '2025-01-15', 40, 2),
      (4, 1, 1, 'Brand Identity Package', 'Logo design, brand guidelines, and marketing materials for product launch', 'on_hold', 'medium', '#6B7280', 12000.00, 'fixed', 95.00, '2024-11-01', '2024-12-20', 25, 2),
      (5, 1, NULL, 'Internal Tool Development', 'Custom project management dashboard for internal team use', 'active', 'low', '#3B82F6', 25000.00, 'hourly', 75.00, '2024-10-20', '2025-02-28', 30, 1)
      ON CONFLICT (id) DO UPDATE SET
        name = EXCLUDED.name,
        description = EXCLUDED.description
      RETURNING *
    `;

    console.log('Created projects:', projects.length);

    // Add project members
    await sql`
      INSERT INTO project_members (project_id, user_id, role, hourly_rate_override) VALUES
      (1, 1, 'manager', NULL),
      (1, 2, 'member', NULL),
      (1, 3, 'member', NULL),
      (2, 1, 'manager', NULL),
      (2, 4, 'member', NULL),
      (2, 3, 'member', NULL),
      (3, 2, 'manager', NULL),
      (3, 4, 'member', NULL),
      (4, 2, 'manager', NULL),
      (4, 3, 'member', NULL),
      (5, 1, 'manager', NULL),
      (5, 4, 'member', NULL)
      ON CONFLICT (project_id, user_id) DO NOTHING
    `;

    // Get task status IDs
    const taskStatuses = await sql`
      SELECT id, name FROM task_statuses WHERE workspace_id = 1 OR workspace_id IS NULL
      ORDER BY sort_order
    `;

    const statusMap = {};
    taskStatuses.forEach(status => {
      statusMap[status.name] = status.id;
    });

    console.log('Status map:', statusMap);

    // Create demo tasks
    const tasks = await sql`
      INSERT INTO tasks (
        project_id, title, description, status_id, priority, assignee_id, reporter_id,
        estimated_hours, due_date, completion_percentage, is_billable
      ) VALUES
      -- E-commerce Website Redesign tasks
      (1, 'User Research & Analysis', 'Conduct user interviews and analyze current website analytics', ${statusMap['Done']}, 'high', 3, 1, 24, '2024-10-15', 100, true),
      (1, 'Wireframe Design', 'Create detailed wireframes for all main pages', ${statusMap['Done']}, 'high', 2, 1, 32, '2024-10-25', 100, true),
      (1, 'UI/UX Design', 'Design high-fidelity mockups based on wireframes', ${statusMap['In Review']}, 'high', 2, 1, 40, '2024-11-10', 90, true),
      (1, 'Frontend Development', 'Implement responsive frontend using React', ${statusMap['In Progress']}, 'high', 3, 1, 60, '2024-11-25', 70, true),
      (1, 'Backend Integration', 'Connect frontend with existing e-commerce APIs', ${statusMap['To Do']}, 'high', 3, 1, 45, '2024-12-05', 0, true),
      (1, 'Testing & QA', 'Comprehensive testing across all devices and browsers', ${statusMap['To Do']}, 'medium', 4, 1, 20, '2024-12-10', 0, true),
      
      -- Mobile App Development tasks  
      (2, 'App Architecture Planning', 'Define technical architecture and data flow', ${statusMap['Done']}, 'urgent', 1, 1, 16, '2024-10-01', 100, true),
      (2, 'iOS App Development', 'Develop native iOS application', ${statusMap['In Progress']}, 'urgent', 4, 1, 80, '2024-11-15', 60, true),
      (2, 'Android App Development', 'Develop native Android application', ${statusMap['In Progress']}, 'urgent', 3, 1, 80, '2024-11-15', 55, true),
      (2, 'API Integration', 'Connect apps with backend services', ${statusMap['To Do']}, 'urgent', 4, 1, 40, '2024-11-20', 0, true),
      (2, 'App Store Submission', 'Prepare and submit apps to stores', ${statusMap['To Do']}, 'high', 1, 1, 16, '2024-11-25', 0, true),
      
      -- SEO & Content Strategy tasks
      (3, 'SEO Audit', 'Complete technical SEO audit of current website', ${statusMap['Done']}, 'medium', 4, 2, 20, '2024-10-30', 100, true),
      (3, 'Keyword Research', 'Research and compile target keyword list', ${statusMap['In Review']}, 'medium', 4, 2, 16, '2024-11-05', 85, true),
      (3, 'Content Calendar', 'Create 3-month content publishing calendar', ${statusMap['In Progress']}, 'medium', 4, 2, 12, '2024-11-15', 50, true),
      (3, 'Blog Content Creation', 'Write 10 SEO-optimized blog posts', ${statusMap['To Do']}, 'medium', 4, 2, 40, '2024-12-15', 0, true),
      
      -- Internal Tool Development tasks
      (5, 'Requirements Gathering', 'Define detailed requirements for internal dashboard', ${statusMap['Done']}, 'low', 1, 1, 12, '2024-10-25', 100, false),
      (5, 'Database Design', 'Design database schema for project data', ${statusMap['In Progress']}, 'low', 4, 1, 16, '2024-11-10', 70, false),
      (5, 'Dashboard UI Development', 'Build responsive dashboard interface', ${statusMap['To Do']}, 'low', 4, 1, 32, '2024-11-30', 0, false)
      RETURNING *
    `;

    console.log('Created tasks:', tasks.length);

    // Add some time entries for realistic data
    const timeEntries = await sql`
      INSERT INTO time_entries (task_id, user_id, description, hours, billable_hours, hourly_rate, is_billable, created_at) VALUES
      (1, 3, 'Conducted user interviews', 8.5, 8.5, 85.00, true, '2024-10-10 09:00:00'),
      (1, 3, 'Analyzed website analytics', 6.0, 6.0, 85.00, true, '2024-10-12 10:00:00'),
      (2, 2, 'Created homepage wireframes', 4.5, 4.5, 95.00, true, '2024-10-20 14:00:00'),
      (2, 2, 'Product page wireframes', 3.0, 3.0, 95.00, true, '2024-10-21 09:30:00'),
      (3, 2, 'Homepage design mockup', 6.5, 6.5, 95.00, true, '2024-10-25 08:00:00'),
      (4, 3, 'Set up React project structure', 4.0, 4.0, 85.00, true, '2024-10-28 13:00:00'),
      (7, 1, 'Architecture documentation', 5.0, 5.0, 105.00, true, '2024-09-28 11:00:00'),
      (8, 4, 'iOS app login screen', 7.5, 7.5, 105.00, true, '2024-10-15 09:00:00'),
      (9, 3, 'Android app setup', 5.5, 5.5, 105.00, true, '2024-10-16 10:30:00'),
      (12, 4, 'Technical SEO analysis', 8.0, 8.0, 85.00, true, '2024-10-22 08:30:00'),
      (13, 4, 'Keyword research tools setup', 3.5, 3.5, 85.00, true, '2024-10-24 14:15:00'),
      (16, 1, 'Requirements meeting with team', 2.0, 0, 75.00, false, '2024-10-23 15:00:00'),
      (17, 4, 'Database schema design', 4.5, 0, 75.00, false, '2024-10-26 10:00:00')
      RETURNING *
    `;

    console.log('Created time entries:', timeEntries.length);

    // Add some comments for collaboration
    await sql`
      INSERT INTO comments (task_id, user_id, content, created_at) VALUES
      (3, 1, 'Great work on the design! The color scheme looks modern and professional. Could we try a slightly warmer shade for the CTA buttons?', '2024-10-26 14:30:00'),
      (3, 2, 'Thanks for the feedback! I''ll create a version with warmer CTA colors and send it over for review.', '2024-10-26 15:45:00'),
      (8, 1, 'How''s the progress on the iOS login screen? Any blockers we should address?', '2024-10-25 16:20:00'),
      (8, 4, 'Making good progress! Just working through some authentication flow edge cases. Should have it ready for review tomorrow.', '2024-10-25 17:10:00'),
      (13, 2, 'Once you finish the keyword research, let''s schedule a meeting to align on content priorities.', '2024-10-24 11:00:00')
    `;

    // Update task actual hours based on time entries
    await sql`
      UPDATE tasks SET 
        actual_hours = COALESCE((
          SELECT SUM(te.hours) 
          FROM time_entries te 
          WHERE te.task_id = tasks.id
        ), 0),
        billable_hours = COALESCE((
          SELECT SUM(te.billable_hours) 
          FROM time_entries te 
          WHERE te.task_id = tasks.id AND te.is_billable = true
        ), 0)
    `;

    console.log('Database seeded successfully!');

    return Response.json({ 
      success: true, 
      message: 'Database seeded with demo data',
      counts: {
        users: users.length,
        projects: projects.length,
        tasks: tasks.length,
        timeEntries: timeEntries.length
      }
    });

  } catch (error) {
    console.error('Error seeding database:', error);
    return Response.json({ error: 'Failed to seed database', details: error.message }, { status: 500 });
  }
}