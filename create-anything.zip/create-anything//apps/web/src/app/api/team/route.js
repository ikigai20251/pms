import sql from "@/app/api/utils/sql";

// Get team members for a workspace
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const workspaceId = searchParams.get('workspace_id');
    const role = searchParams.get('role');

    if (!workspaceId) {
      return Response.json({ error: 'Workspace ID is required' }, { status: 400 });
    }

    let query = `
      SELECT u.*, 
             wm.role as workspace_role,
             wm.permissions,
             wm.joined_at,
             COUNT(DISTINCT pa.project_id) as assigned_projects,
             COUNT(DISTINCT t.id) as assigned_tasks,
             COUNT(DISTINCT CASE WHEN ts.is_done = false THEN t.id END) as active_tasks,
             COALESCE(SUM(te.hours), 0) as total_hours_logged,
             COALESCE(AVG(te.hours), 0) as avg_daily_hours,
             COALESCE(SUM(CASE WHEN te.is_billable THEN te.billable_hours * te.hourly_rate ELSE 0 END), 0) as total_revenue_generated
      FROM users u
      JOIN workspace_members wm ON u.id = wm.user_id
      LEFT JOIN project_members pa ON u.id = pa.user_id
      LEFT JOIN tasks t ON u.id = t.assignee_id
      LEFT JOIN task_statuses ts ON t.status_id = ts.id
      LEFT JOIN time_entries te ON u.id = te.user_id AND te.created_at >= CURRENT_DATE - INTERVAL '30 days'
      WHERE wm.workspace_id = $1 AND u.is_active = true
    `;

    const params = [workspaceId];
    let paramCount = 1;

    if (role) {
      paramCount++;
      query += ` AND wm.role = $${paramCount}`;
      params.push(role);
    }

    query += `
      GROUP BY u.id, wm.role, wm.permissions, wm.joined_at
      ORDER BY wm.role DESC, u.first_name ASC
    `;

    const teamMembers = await sql(query, params);
    return Response.json(teamMembers);
  } catch (error) {
    console.error('Error fetching team members:', error);
    return Response.json({ error: 'Failed to fetch team members' }, { status: 500 });
  }
}

// Add team member to workspace
export async function POST(request) {
  try {
    const {
      workspace_id,
      user_id,
      email,
      first_name,
      last_name,
      role = 'member',
      hourly_rate,
      permissions = {}
    } = await request.json();

    if (!workspace_id) {
      return Response.json({ error: 'Workspace ID is required' }, { status: 400 });
    }

    let userId = user_id;

    // If no user_id provided, create new user
    if (!userId && email && first_name && last_name) {
      const [existingUser] = await sql`
        SELECT id FROM users WHERE email = ${email}
      `;

      if (existingUser) {
        userId = existingUser.id;
      } else {
        const [newUser] = await sql`
          INSERT INTO users (email, first_name, last_name, hourly_rate)
          VALUES (${email}, ${first_name}, ${last_name}, ${hourly_rate || 0})
          RETURNING *
        `;
        userId = newUser.id;
      }
    }

    if (!userId) {
      return Response.json({ error: 'User ID or user details are required' }, { status: 400 });
    }

    // Check if already a member
    const [existingMember] = await sql`
      SELECT id FROM workspace_members WHERE workspace_id = ${workspace_id} AND user_id = ${userId}
    `;

    if (existingMember) {
      return Response.json({ error: 'User is already a member of this workspace' }, { status: 400 });
    }

    // Add to workspace
    const [workspaceMember] = await sql`
      INSERT INTO workspace_members (workspace_id, user_id, role, permissions)
      VALUES (${workspace_id}, ${userId}, ${role}, ${JSON.stringify(permissions)})
      RETURNING *
    `;

    // Get full member details
    const [memberDetails] = await sql`
      SELECT u.*, wm.role as workspace_role, wm.permissions, wm.joined_at
      FROM users u
      JOIN workspace_members wm ON u.id = wm.user_id
      WHERE wm.id = ${workspaceMember.id}
    `;

    return Response.json(memberDetails);
  } catch (error) {
    console.error('Error adding team member:', error);
    return Response.json({ error: 'Failed to add team member' }, { status: 500 });
  }
}

// Update team member
export async function PUT(request) {
  try {
    const {
      workspace_id,
      user_id,
      role,
      hourly_rate,
      permissions,
      is_active
    } = await request.json();

    if (!workspace_id || !user_id) {
      return Response.json({ error: 'Workspace ID and User ID are required' }, { status: 400 });
    }

    // Update workspace member role/permissions
    if (role !== undefined || permissions !== undefined) {
      const updates = [];
      const values = [];

      if (role !== undefined) {
        updates.push(`role = $${values.length + 1}`);
        values.push(role);
      }
      if (permissions !== undefined) {
        updates.push(`permissions = $${values.length + 1}`);
        values.push(JSON.stringify(permissions));
      }

      if (updates.length > 0) {
        await sql(
          `UPDATE workspace_members SET ${updates.join(', ')} WHERE workspace_id = $${values.length + 1} AND user_id = $${values.length + 2}`,
          [...values, workspace_id, user_id]
        );
      }
    }

    // Update user details
    const userUpdates = [];
    const userValues = [];

    if (hourly_rate !== undefined) {
      userUpdates.push(`hourly_rate = $${userValues.length + 1}`);
      userValues.push(hourly_rate);
    }
    if (is_active !== undefined) {
      userUpdates.push(`is_active = $${userValues.length + 1}`);
      userValues.push(is_active);
    }

    if (userUpdates.length > 0) {
      userUpdates.push(`updated_at = CURRENT_TIMESTAMP`);
      await sql(
        `UPDATE users SET ${userUpdates.join(', ')} WHERE id = $${userValues.length + 1}`,
        [...userValues, user_id]
      );
    }

    // Return updated member details
    const [memberDetails] = await sql`
      SELECT u.*, wm.role as workspace_role, wm.permissions, wm.joined_at
      FROM users u
      JOIN workspace_members wm ON u.id = wm.user_id
      WHERE wm.workspace_id = ${workspace_id} AND wm.user_id = ${user_id}
    `;

    return Response.json(memberDetails);
  } catch (error) {
    console.error('Error updating team member:', error);
    return Response.json({ error: 'Failed to update team member' }, { status: 500 });
  }
}