import sql from "@/app/api/utils/sql";

// Get comprehensive reports
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const workspaceId = searchParams.get('workspace_id');
    const reportType = searchParams.get('type');
    const startDate = searchParams.get('start_date');
    const endDate = searchParams.get('end_date');
    const projectId = searchParams.get('project_id');
    const userId = searchParams.get('user_id');

    if (!workspaceId) {
      return Response.json({ error: 'Workspace ID is required' }, { status: 400 });
    }

    switch (reportType) {
      case 'time_tracking':
        return await getTimeTrackingReport(workspaceId, startDate, endDate, projectId, userId);
      case 'project_profitability':
        return await getProjectProfitabilityReport(workspaceId, startDate, endDate, projectId);
      case 'team_productivity':
        return await getTeamProductivityReport(workspaceId, startDate, endDate, userId);
      case 'client_revenue':
        return await getClientRevenueReport(workspaceId, startDate, endDate);
      case 'task_completion':
        return await getTaskCompletionReport(workspaceId, startDate, endDate, projectId);
      case 'financial_summary':
        return await getFinancialSummaryReport(workspaceId, startDate, endDate);
      default:
        return await getDashboardReports(workspaceId, startDate, endDate);
    }
  } catch (error) {
    console.error('Error generating reports:', error);
    return Response.json({ error: 'Failed to generate reports' }, { status: 500 });
  }
}

async function getTimeTrackingReport(workspaceId, startDate, endDate, projectId, userId) {
  let query = `
    SELECT 
      te.*,
      t.title as task_title,
      p.name as project_name,
      p.color as project_color,
      c.name as client_name,
      u.first_name || ' ' || u.last_name as user_name,
      CASE WHEN te.is_billable THEN te.billable_hours * te.hourly_rate ELSE 0 END as revenue
    FROM time_entries te
    JOIN tasks t ON te.task_id = t.id
    JOIN projects p ON t.project_id = p.id
    LEFT JOIN clients c ON p.client_id = c.id
    JOIN users u ON te.user_id = u.id
    WHERE p.workspace_id = $1
  `;

  const params = [workspaceId];
  let paramCount = 1;

  if (startDate) {
    paramCount++;
    query += ` AND te.created_at >= $${paramCount}`;
    params.push(startDate);
  }

  if (endDate) {
    paramCount++;
    query += ` AND te.created_at <= $${paramCount}`;
    params.push(endDate);
  }

  if (projectId) {
    paramCount++;
    query += ` AND p.id = $${paramCount}`;
    params.push(projectId);
  }

  if (userId) {
    paramCount++;
    query += ` AND te.user_id = $${paramCount}`;
    params.push(userId);
  }

  query += ` ORDER BY te.created_at DESC`;

  const timeEntries = await sql(query, params);

  // Summary statistics
  const [summary] = await sql(
    `SELECT 
       COUNT(*) as total_entries,
       SUM(hours) as total_hours,
       SUM(billable_hours) as total_billable_hours,
       SUM(CASE WHEN is_billable THEN billable_hours * hourly_rate ELSE 0 END) as total_revenue,
       AVG(hours) as avg_hours_per_entry
     FROM time_entries te
     JOIN tasks t ON te.task_id = t.id
     JOIN projects p ON t.project_id = p.id
     WHERE p.workspace_id = $1 ${startDate ? `AND te.created_at >= $2` : ''} ${endDate ? `AND te.created_at <= $${startDate ? 3 : 2}` : ''}`,
    params.slice(0, 1 + (startDate ? 1 : 0) + (endDate ? 1 : 0))
  );

  return Response.json({
    type: 'time_tracking',
    data: timeEntries,
    summary
  });
}

async function getProjectProfitabilityReport(workspaceId, startDate, endDate, projectId) {
  let query = `
    SELECT 
      p.*,
      c.name as client_name,
      COALESCE(SUM(te.billable_hours), 0) as total_billable_hours,
      COALESCE(SUM(te.billable_hours * te.hourly_rate), 0) as total_revenue,
      COALESCE(p.budget, 0) as budget,
      CASE 
        WHEN p.budget > 0 THEN 
          ROUND(((COALESCE(SUM(te.billable_hours * te.hourly_rate), 0) - p.budget) / p.budget * 100), 2)
        ELSE 0 
      END as profit_margin_percentage,
      COUNT(DISTINCT t.id) as total_tasks,
      COUNT(DISTINCT CASE WHEN ts.is_done = true THEN t.id END) as completed_tasks
    FROM projects p
    LEFT JOIN clients c ON p.client_id = c.id
    LEFT JOIN tasks t ON p.id = t.project_id
    LEFT JOIN task_statuses ts ON t.status_id = ts.id
    LEFT JOIN time_entries te ON t.id = te.task_id AND te.is_billable = true
    WHERE p.workspace_id = $1
  `;

  const params = [workspaceId];
  let paramCount = 1;

  if (projectId) {
    paramCount++;
    query += ` AND p.id = $${paramCount}`;
    params.push(projectId);
  }

  if (startDate) {
    paramCount++;
    query += ` AND te.created_at >= $${paramCount}`;
    params.push(startDate);
  }

  if (endDate) {
    paramCount++;
    query += ` AND te.created_at <= $${paramCount}`;
    params.push(endDate);
  }

  query += `
    GROUP BY p.id, c.name
    ORDER BY total_revenue DESC
  `;

  const projects = await sql(query, params);

  return Response.json({
    type: 'project_profitability',
    data: projects
  });
}

async function getTeamProductivityReport(workspaceId, startDate, endDate, userId) {
  let query = `
    SELECT 
      u.id,
      u.first_name || ' ' || u.last_name as name,
      u.avatar_url,
      u.hourly_rate,
      COUNT(DISTINCT t.id) as assigned_tasks,
      COUNT(DISTINCT CASE WHEN ts.is_done = true THEN t.id END) as completed_tasks,
      COALESCE(SUM(te.hours), 0) as total_hours,
      COALESCE(SUM(te.billable_hours), 0) as billable_hours,
      COALESCE(SUM(te.billable_hours * te.hourly_rate), 0) as revenue_generated,
      ROUND(
        CASE 
          WHEN COUNT(DISTINCT t.id) > 0 THEN 
            (COUNT(DISTINCT CASE WHEN ts.is_done = true THEN t.id END) * 100.0) / COUNT(DISTINCT t.id)
          ELSE 0 
        END, 2
      ) as completion_rate
    FROM users u
    JOIN workspace_members wm ON u.id = wm.user_id
    LEFT JOIN tasks t ON u.id = t.assignee_id
    LEFT JOIN task_statuses ts ON t.status_id = ts.id
    LEFT JOIN time_entries te ON u.id = te.user_id
    WHERE wm.workspace_id = $1 AND u.is_active = true
  `;

  const params = [workspaceId];
  let paramCount = 1;

  if (userId) {
    paramCount++;
    query += ` AND u.id = $${paramCount}`;
    params.push(userId);
  }

  if (startDate) {
    paramCount++;
    query += ` AND (te.created_at IS NULL OR te.created_at >= $${paramCount})`;
    params.push(startDate);
  }

  if (endDate) {
    paramCount++;
    query += ` AND (te.created_at IS NULL OR te.created_at <= $${paramCount})`;
    params.push(endDate);
  }

  query += `
    GROUP BY u.id, u.first_name, u.last_name, u.avatar_url, u.hourly_rate
    ORDER BY revenue_generated DESC
  `;

  const teamMembers = await sql(query, params);

  return Response.json({
    type: 'team_productivity',
    data: teamMembers
  });
}

async function getClientRevenueReport(workspaceId, startDate, endDate) {
  let query = `
    SELECT 
      c.*,
      COUNT(DISTINCT p.id) as total_projects,
      COUNT(DISTINCT CASE WHEN p.status = 'active' THEN p.id END) as active_projects,
      COALESCE(SUM(te.billable_hours), 0) as total_billable_hours,
      COALESCE(SUM(te.billable_hours * te.hourly_rate), 0) as total_revenue,
      COALESCE(SUM(CASE WHEN DATE(te.created_at) >= CURRENT_DATE - INTERVAL '30 days' THEN te.billable_hours * te.hourly_rate ELSE 0 END), 0) as revenue_last_30_days
    FROM clients c
    LEFT JOIN projects p ON c.id = p.client_id
    LEFT JOIN tasks t ON p.id = t.project_id
    LEFT JOIN time_entries te ON t.id = te.task_id AND te.is_billable = true
    WHERE c.workspace_id = $1
  `;

  const params = [workspaceId];
  let paramCount = 1;

  if (startDate) {
    paramCount++;
    query += ` AND (te.created_at IS NULL OR te.created_at >= $${paramCount})`;
    params.push(startDate);
  }

  if (endDate) {
    paramCount++;
    query += ` AND (te.created_at IS NULL OR te.created_at <= $${paramCount})`;
    params.push(endDate);
  }

  query += `
    GROUP BY c.id
    ORDER BY total_revenue DESC
  `;

  const clients = await sql(query, params);

  return Response.json({
    type: 'client_revenue',
    data: clients
  });
}

async function getTaskCompletionReport(workspaceId, startDate, endDate, projectId) {
  let query = `
    SELECT 
      DATE(t.created_at) as date,
      COUNT(*) as tasks_created,
      COUNT(CASE WHEN ts.is_done = true THEN 1 END) as tasks_completed,
      p.name as project_name,
      p.color as project_color
    FROM tasks t
    JOIN projects p ON t.project_id = p.id
    LEFT JOIN task_statuses ts ON t.status_id = ts.id
    WHERE p.workspace_id = $1
  `;

  const params = [workspaceId];
  let paramCount = 1;

  if (startDate) {
    paramCount++;
    query += ` AND t.created_at >= $${paramCount}`;
    params.push(startDate);
  }

  if (endDate) {
    paramCount++;
    query += ` AND t.created_at <= $${paramCount}`;
    params.push(endDate);
  }

  if (projectId) {
    paramCount++;
    query += ` AND p.id = $${paramCount}`;
    params.push(projectId);
  }

  query += `
    GROUP BY DATE(t.created_at), p.name, p.color
    ORDER BY date DESC
  `;

  const taskData = await sql(query, params);

  return Response.json({
    type: 'task_completion',
    data: taskData
  });
}

async function getFinancialSummaryReport(workspaceId, startDate, endDate) {
  const [summary] = await sql`
    SELECT 
      COALESCE(SUM(te.billable_hours * te.hourly_rate), 0) as total_revenue,
      COALESCE(SUM(te.billable_hours), 0) as total_billable_hours,
      COALESCE(AVG(te.hourly_rate), 0) as avg_hourly_rate,
      COUNT(DISTINCT p.id) as active_projects,
      COUNT(DISTINCT c.id) as active_clients,
      COUNT(DISTINCT u.id) as team_members
    FROM time_entries te
    JOIN tasks t ON te.task_id = t.id
    JOIN projects p ON t.project_id = p.id
    LEFT JOIN clients c ON p.client_id = c.id
    JOIN users u ON te.user_id = u.id
    WHERE p.workspace_id = ${workspaceId} AND te.is_billable = true
      ${startDate ? sql`AND te.created_at >= ${startDate}` : sql``}
      ${endDate ? sql`AND te.created_at <= ${endDate}` : sql``}
  `;

  return Response.json({
    type: 'financial_summary',
    data: summary
  });
}

async function getDashboardReports(workspaceId, startDate, endDate) {
  const reports = await Promise.all([
    getTimeTrackingReport(workspaceId, startDate, endDate),
    getProjectProfitabilityReport(workspaceId, startDate, endDate),
    getTeamProductivityReport(workspaceId, startDate, endDate),
    getFinancialSummaryReport(workspaceId, startDate, endDate)
  ]);

  return Response.json({
    type: 'dashboard',
    data: {
      timeTracking: reports[0],
      projectProfitability: reports[1],
      teamProductivity: reports[2],
      financialSummary: reports[3]
    }
  });
}