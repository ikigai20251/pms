import sql from "@/app/api/utils/sql";

// Get time entries
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const taskId = searchParams.get('task_id');
    const userId = searchParams.get('user_id');
    const startDate = searchParams.get('start_date');
    const endDate = searchParams.get('end_date');

    let query = `
      SELECT te.*, 
             t.title as task_title,
             t.project_id,
             p.name as project_name,
             u.first_name,
             u.last_name
      FROM time_entries te
      LEFT JOIN tasks t ON te.task_id = t.id
      LEFT JOIN projects p ON t.project_id = p.id
      LEFT JOIN users u ON te.user_id = u.id
      WHERE 1=1
    `;
    
    const params = [];
    let paramIndex = 1;
    
    if (taskId) {
      query += ` AND te.task_id = $${paramIndex}`;
      params.push(taskId);
      paramIndex++;
    }
    
    if (userId) {
      query += ` AND te.user_id = $${paramIndex}`;
      params.push(userId);
      paramIndex++;
    }
    
    if (startDate) {
      query += ` AND DATE(te.created_at) >= $${paramIndex}`;
      params.push(startDate);
      paramIndex++;
    }
    
    if (endDate) {
      query += ` AND DATE(te.created_at) <= $${paramIndex}`;
      params.push(endDate);
      paramIndex++;
    }

    query += ` ORDER BY te.created_at DESC`;

    const timeEntries = await sql(query, params);

    return Response.json(timeEntries);
  } catch (error) {
    console.error('Error fetching time entries:', error);
    return Response.json({ error: 'Failed to fetch time entries' }, { status: 500 });
  }
}

// Create a new time entry or start timer
export async function POST(request) {
  try {
    const { 
      task_id,
      user_id,
      description,
      hours,
      is_billable,
      start_timer,
      hourly_rate
    } = await request.json();

    if (!task_id || !user_id) {
      return Response.json({ error: 'Task ID and User ID are required' }, { status: 400 });
    }

    if (start_timer) {
      // Stop any existing running timers for this user
      await sql`
        UPDATE time_entries 
        SET is_running = false, 
            end_time = CURRENT_TIMESTAMP,
            hours = EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - start_time)) / 3600
        WHERE user_id = ${user_id} AND is_running = true
      `;

      // Start new timer
      const [timeEntry] = await sql`
        INSERT INTO time_entries (
          task_id, user_id, description, hours, is_billable, 
          hourly_rate, is_running, start_time
        )
        VALUES (
          ${task_id}, ${user_id}, ${description || ''}, 0, 
          ${is_billable !== false}, ${hourly_rate || 0}, true, CURRENT_TIMESTAMP
        )
        RETURNING *
      `;

      return Response.json(timeEntry);
    } else {
      // Manual time entry
      if (!hours || hours <= 0) {
        return Response.json({ error: 'Hours must be greater than 0' }, { status: 400 });
      }

      const billableHours = is_billable !== false ? hours : 0;

      const [timeEntry] = await sql`
        INSERT INTO time_entries (
          task_id, user_id, description, hours, billable_hours,
          is_billable, hourly_rate
        )
        VALUES (
          ${task_id}, ${user_id}, ${description || ''}, ${hours}, 
          ${billableHours}, ${is_billable !== false}, ${hourly_rate || 0}
        )
        RETURNING *
      `;

      // Update task actual hours
      await sql`
        UPDATE tasks 
        SET actual_hours = actual_hours + ${hours},
            billable_hours = billable_hours + ${billableHours}
        WHERE id = ${task_id}
      `;

      return Response.json(timeEntry);
    }
  } catch (error) {
    console.error('Error creating time entry:', error);
    return Response.json({ error: 'Failed to create time entry' }, { status: 500 });
  }
}