import sql from "@/app/api/utils/sql";

// Get all tasks for a project
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const projectId = searchParams.get('project_id');
    const assigneeId = searchParams.get('assignee_id');
    const status = searchParams.get('status');

    if (!projectId) {
      return Response.json({ error: 'Project ID is required' }, { status: 400 });
    }

    let query = `
      SELECT t.*, 
             ts.name as status_name,
             ts.color as status_color,
             ts.is_done as status_is_done,
             assignee.first_name as assignee_first_name,
             assignee.last_name as assignee_last_name,
             assignee.avatar_url as assignee_avatar,
             reporter.first_name as reporter_first_name,
             reporter.last_name as reporter_last_name,
             COALESCE(SUM(te.hours), 0) as total_time_logged,
             COUNT(DISTINCT c.id) as comment_count,
             COUNT(DISTINCT cl.id) as checklist_count,
             COUNT(DISTINCT CASE WHEN cl.is_completed = true THEN cl.id END) as completed_checklist_count
      FROM tasks t
      LEFT JOIN task_statuses ts ON t.status_id = ts.id
      LEFT JOIN users assignee ON t.assignee_id = assignee.id
      LEFT JOIN users reporter ON t.reporter_id = reporter.id
      LEFT JOIN time_entries te ON t.id = te.task_id
      LEFT JOIN comments c ON t.id = c.task_id
      LEFT JOIN task_checklist_items cl ON t.id = cl.task_id
      WHERE t.project_id = $1
    `;
    
    const params = [projectId];
    let paramIndex = 2;
    
    if (assigneeId) {
      query += ` AND t.assignee_id = $${paramIndex}`;
      params.push(assigneeId);
      paramIndex++;
    }
    
    if (status) {
      query += ` AND ts.name = $${paramIndex}`;
      params.push(status);
      paramIndex++;
    }

    query += `
      GROUP BY t.id, ts.name, ts.color, ts.is_done, 
               assignee.first_name, assignee.last_name, assignee.avatar_url,
               reporter.first_name, reporter.last_name
      ORDER BY t.sort_order ASC, t.created_at DESC
    `;

    const tasks = await sql(query, params);

    return Response.json(tasks);
  } catch (error) {
    console.error('Error fetching tasks:', error);
    return Response.json({ error: 'Failed to fetch tasks' }, { status: 500 });
  }
}

// Create a new task
export async function POST(request) {
  try {
    const { 
      project_id,
      parent_task_id,
      title,
      description,
      priority,
      assignee_id,
      estimated_hours,
      due_date,
      is_billable
    } = await request.json();

    if (!project_id || !title) {
      return Response.json({ error: 'Project ID and title are required' }, { status: 400 });
    }

    // Get the default "To Do" status for this workspace
    const [defaultStatus] = await sql`
      SELECT ts.* FROM task_statuses ts
      JOIN projects p ON p.workspace_id = ts.workspace_id OR ts.workspace_id IS NULL
      WHERE p.id = ${project_id} AND ts.is_default = true
      ORDER BY ts.workspace_id DESC NULLS LAST
      LIMIT 1
    `;

    if (!defaultStatus) {
      return Response.json({ error: 'No default task status found' }, { status: 400 });
    }

    const [task] = await sql`
      INSERT INTO tasks (
        project_id, parent_task_id, title, description, status_id, priority,
        assignee_id, estimated_hours, due_date, is_billable
      )
      VALUES (
        ${project_id}, ${parent_task_id || null}, ${title}, ${description || null},
        ${defaultStatus.id}, ${priority || 'medium'}, ${assignee_id || null},
        ${estimated_hours || 0}, ${due_date || null}, ${is_billable !== false}
      )
      RETURNING *
    `;

    // Get the full task with related data
    const [fullTask] = await sql`
      SELECT t.*, 
             ts.name as status_name,
             ts.color as status_color,
             assignee.first_name as assignee_first_name,
             assignee.last_name as assignee_last_name,
             assignee.avatar_url as assignee_avatar
      FROM tasks t
      LEFT JOIN task_statuses ts ON t.status_id = ts.id
      LEFT JOIN users assignee ON t.assignee_id = assignee.id
      WHERE t.id = ${task.id}
    `;

    return Response.json(fullTask);
  } catch (error) {
    console.error('Error creating task:', error);
    return Response.json({ error: 'Failed to create task' }, { status: 500 });
  }
}