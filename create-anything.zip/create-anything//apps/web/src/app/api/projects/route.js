import sql from "@/app/api/utils/sql";

// Get all projects for a workspace
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const workspaceId = searchParams.get("workspace_id");
    const status = searchParams.get("status");
    const clientId = searchParams.get("client_id");

    if (!workspaceId) {
      return Response.json(
        { error: "Workspace ID is required" },
        { status: 400 },
      );
    }

    let query = `
      SELECT p.*, 
             c.name as client_name,
             c.company as client_company,
             COUNT(DISTINCT t.id) as task_count,
             COUNT(DISTINCT CASE WHEN ts.is_done = true THEN t.id END) as completed_tasks,
             COALESCE(SUM(te.billable_hours), 0) as total_hours,
             COALESCE(SUM(te.billable_hours * COALESCE(te.hourly_rate, p.hourly_rate, 0)), 0) as total_revenue,
             creator.first_name || ' ' || creator.last_name as created_by_name
      FROM projects p
      LEFT JOIN clients c ON p.client_id = c.id
      LEFT JOIN tasks t ON p.id = t.project_id
      LEFT JOIN task_statuses ts ON t.status_id = ts.id
      LEFT JOIN time_entries te ON t.id = te.task_id AND te.is_billable = true
      LEFT JOIN users creator ON p.created_by = creator.id
      WHERE p.workspace_id = $1
    `;

    const params = [workspaceId];
    let paramCount = 1;

    if (status) {
      paramCount++;
      query += ` AND p.status = $${paramCount}`;
      params.push(status);
    }

    if (clientId) {
      paramCount++;
      query += ` AND p.client_id = $${paramCount}`;
      params.push(clientId);
    }

    query += `
      GROUP BY p.id, c.name, c.company, creator.first_name, creator.last_name
      ORDER BY p.is_favorite DESC, p.updated_at DESC
    `;

    const projects = await sql(query, params);

    return Response.json(projects);
  } catch (error) {
    console.error("Error fetching projects:", error);
    return Response.json(
      { error: "Failed to fetch projects" },
      { status: 500 },
    );
  }
}

// Create a new project
export async function POST(request) {
  try {
    const {
      workspace_id,
      client_id,
      name,
      description,
      priority,
      color,
      budget,
      budget_type,
      hourly_rate,
      start_date,
      due_date,
      created_by,
    } = await request.json();

    if (!workspace_id || !name) {
      return Response.json(
        { error: "Workspace ID and name are required" },
        { status: 400 },
      );
    }

    const [project] = await sql`
      INSERT INTO projects (
        workspace_id, client_id, name, description, priority, color,
        budget, budget_type, hourly_rate, start_date, due_date, created_by
      )
      VALUES (
        ${workspace_id}, ${client_id || null}, ${name}, ${description || null}, 
        ${priority || "medium"}, ${color || "#6B7280"}, ${budget || 0}, 
        ${budget_type || "fixed"}, ${hourly_rate || null}, 
        ${start_date || null}, ${due_date || null}, ${created_by || null}
      )
      RETURNING *
    `;

    return Response.json(project);
  } catch (error) {
    console.error("Error creating project:", error);
    return Response.json(
      { error: "Failed to create project" },
      { status: 500 },
    );
  }
}

// Update a project
export async function PUT(request) {
  try {
    const {
      id,
      name,
      description,
      status,
      priority,
      color,
      budget,
      budget_type,
      hourly_rate,
      start_date,
      due_date,
      completion_percentage,
      is_favorite,
    } = await request.json();

    if (!id) {
      return Response.json(
        { error: "Project ID is required" },
        { status: 400 },
      );
    }

    // Build dynamic update query
    const updates = [];
    const values = [];

    if (name !== undefined) {
      updates.push(`name = $${values.length + 1}`);
      values.push(name);
    }
    if (description !== undefined) {
      updates.push(`description = $${values.length + 1}`);
      values.push(description);
    }
    if (status !== undefined) {
      updates.push(`status = $${values.length + 1}`);
      values.push(status);
    }
    if (priority !== undefined) {
      updates.push(`priority = $${values.length + 1}`);
      values.push(priority);
    }
    if (color !== undefined) {
      updates.push(`color = $${values.length + 1}`);
      values.push(color);
    }
    if (budget !== undefined) {
      updates.push(`budget = $${values.length + 1}`);
      values.push(budget);
    }
    if (budget_type !== undefined) {
      updates.push(`budget_type = $${values.length + 1}`);
      values.push(budget_type);
    }
    if (hourly_rate !== undefined) {
      updates.push(`hourly_rate = $${values.length + 1}`);
      values.push(hourly_rate);
    }
    if (start_date !== undefined) {
      updates.push(`start_date = $${values.length + 1}`);
      values.push(start_date);
    }
    if (due_date !== undefined) {
      updates.push(`due_date = $${values.length + 1}`);
      values.push(due_date);
    }
    if (completion_percentage !== undefined) {
      updates.push(`completion_percentage = $${values.length + 1}`);
      values.push(completion_percentage);
    }
    if (is_favorite !== undefined) {
      updates.push(`is_favorite = $${values.length + 1}`);
      values.push(is_favorite);
    }

    updates.push(`updated_at = CURRENT_TIMESTAMP`);

    const [project] = await sql(
      `UPDATE projects SET ${updates.join(", ")} WHERE id = $${values.length + 1} RETURNING *`,
      [...values, id],
    );

    return Response.json(project);
  } catch (error) {
    console.error("Error updating project:", error);
    return Response.json(
      { error: "Failed to update project" },
      { status: 500 },
    );
  }
}
