import sql from "@/app/api/utils/sql";

// Get all workspaces for a user
export async function GET(request) {
  try {
    const workspaces = await sql`
      SELECT w.*, 
             COUNT(p.id) as project_count,
             COUNT(CASE WHEN p.status = 'active' THEN 1 END) as active_projects
      FROM workspaces w
      LEFT JOIN projects p ON w.id = p.workspace_id
      WHERE w.is_active = true
      GROUP BY w.id
      ORDER BY w.created_at DESC
    `;

    return Response.json(workspaces);
  } catch (error) {
    console.error('Error fetching workspaces:', error);
    return Response.json({ error: 'Failed to fetch workspaces' }, { status: 500 });
  }
}

// Create a new workspace
export async function POST(request) {
  try {
    const { name, description, primary_color } = await request.json();

    if (!name) {
      return Response.json({ error: 'Name is required' }, { status: 400 });
    }

    // Generate slug from name
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');

    const [workspace] = await sql`
      INSERT INTO workspaces (name, slug, description, primary_color)
      VALUES (${name}, ${slug}, ${description || null}, ${primary_color || '#3B82F6'})
      RETURNING *
    `;

    return Response.json(workspace);
  } catch (error) {
    console.error('Error creating workspace:', error);
    return Response.json({ error: 'Failed to create workspace' }, { status: 500 });
  }
}